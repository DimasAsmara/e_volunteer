
<?php include_once("header.php"); ?>

<?php echo $content; ?>
<?php include_once("footer.php"); ?>
