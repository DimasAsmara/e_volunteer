<?php
defined('BASEPATH') or exit('No direct script access allowed');

echo "\nERROR: ",
$heading,
"\n\n",
$message,
"\n\n";
